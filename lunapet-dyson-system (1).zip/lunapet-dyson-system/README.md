# lunapet-dyson-system - Libreria artistica per Claude

## Come usarla con Claude (dopo aver collegato GitHub)
1. In Claude Code: `Leggi il repo lunapet-dyson-system e usa tokens/dyson.json come design system`
2. Prompt magico: `Usa come libreria artistica lunapet-dyson-system. Applica tokens/dyson.json e components/nival-*.liquid al tema Shopify draft 191321637188. Non inventare design.`
3. Metti le 2 immagini generate in assets/: lunagroom-dyson-light.webp e lunagroom-nival-dark.webp

## Cosa contiene
- tokens/dyson.json: colori, font, radius Dyson
- components/: 2 hero pronti (light e dark Nival)
- prompts/nival-cyberspace.md: prompt MotionSites ricostruito free
- references/: metti qui 5 screenshot Dyson/Apple che ti piacciono
