# Nival Cyberspace - MotionSites prompt (free reconstruction)

Tech stack: React + Vite + Tailwind + Framer Motion + Lucide

Prompt: Dark premium hero #0A0A0A with subtle grid 60px, glowing orbiting ring #FFC24C above floating product, volumetric fog, golden particles bokeh, rim light on product, slow spiral floating animation, minimal Apple/Dyson copy

Usage for Shopify: Translate to Liquid section with CSS grid + absolute ring div + float animation 6s ease-in-out, background #0A0A0A
